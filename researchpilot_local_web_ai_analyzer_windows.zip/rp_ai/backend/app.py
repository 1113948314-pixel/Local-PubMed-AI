import os, json, csv, re, webbrowser, threading
from pathlib import Path
from datetime import datetime
from xml.etree import ElementTree as ET
from urllib.parse import quote
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / 'config'; EXPORT_DIR = ROOT / 'exports'; LOG_DIR = ROOT / 'logs'
SETTINGS = CONFIG_DIR / 'settings.json'
for d in (CONFIG_DIR, EXPORT_DIR, LOG_DIR): d.mkdir(exist_ok=True)
app = Flask(__name__, template_folder=str(ROOT/'templates'), static_folder=str(ROOT/'static'))

PROVIDERS = {
    'OpenAI / GPT': {'type':'openai','base_url':'https://api.openai.com/v1','models':['gpt-5.5','gpt-5.5-mini','gpt-4.1','gpt-4.1-mini']},
    'DeepSeek': {'type':'openai','base_url':'https://api.deepseek.com','models':['deepseek-chat','deepseek-reasoner','deepseek-v4-flash','deepseek-v4-pro']},
    'Claude / Anthropic': {'type':'anthropic','base_url':'https://api.anthropic.com','models':['claude-sonnet-4-5','claude-3-5-sonnet-latest','claude-3-5-haiku-latest']},
    '阿里通义 / DashScope': {'type':'openai','base_url':'https://dashscope.aliyuncs.com/compatible-mode/v1','models':['qwen-plus','qwen-max','qwen-turbo','qwen-long']},
    '本地 Ollama': {'type':'ollama','base_url':'http://localhost:11434','models':['qwen2.5:7b','qwen2.5:14b','llama3.1:8b','deepseek-r1:7b']},
    '自定义 OpenAI-Compatible': {'type':'openai','base_url':'https://api.openai.com/v1','models':['填写你的模型名']}
}
last_results=[]; last_query=''; last_log=[]

def log(msg):
    global last_log
    line=f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
    last_log.append(line); last_log=last_log[-120:]
    (LOG_DIR/'run.log').open('a',encoding='utf-8').write(line+'\n')

def load_settings():
    if SETTINGS.exists():
        try: return json.loads(SETTINGS.read_text(encoding='utf-8'))
        except Exception: pass
    return {'ncbi_api_key':'','email':'','provider':'OpenAI / GPT','base_url':PROVIDERS['OpenAI / GPT']['base_url'],'api_key':'','model':PROVIDERS['OpenAI / GPT']['models'][0]}

def save_settings(data):
    cur=load_settings(); cur.update(data); SETTINGS.write_text(json.dumps(cur,ensure_ascii=False,indent=2),encoding='utf-8'); return cur

def split_terms(s): return [x.strip() for x in re.split(r'[,，;；\n]+', s or '') if x.strip()]
def quote_term(s):
    s=s.strip()
    if not s: return ''
    if any(op in s.upper() for op in [' AND ',' OR ','[TIAB]','[MH]','[AD]','[AU]','"','(',')']): return f'({s})'
    return f'"{s}"' if (' ' in s or '-' in s) else s

def build_query(data):
    custom=(data.get('custom_query') or '').strip()
    if custom: return custom
    parts=[]
    for key in ('cancer','direction','topic'):
        v=(data.get(key) or '').strip()
        if v: parts.append(v if any(x in v for x in ['OR','AND','(',')','"']) else quote_term(v))
    for t in split_terms(data.get('required','')): parts.append(quote_term(t))
    start=(data.get('start_year') or '').strip(); end=(data.get('end_year') or '').strip()
    if start and end: parts.append(f'("{start}"[Date - Publication] : "{end}"[Date - Publication])')
    if data.get('mode')=='limited':
        if data.get('author'): parts.append(f'{quote_term(data.get("author"))}[Author]')
        if data.get('affiliation'): parts.append(f'{quote_term(data.get("affiliation"))}[Affiliation]')
        if data.get('journal'): parts.append(f'{quote_term(data.get("journal"))}[Journal]')
    for t in split_terms(data.get('exclude','')): parts.append(f'NOT {quote_term(t)}')
    return ' AND '.join([p for p in parts if p])

def ncbi_params(settings):
    p={}
    if settings.get('ncbi_api_key'): p['api_key']=settings['ncbi_api_key']
    if settings.get('email'): p['email']=settings['email']
    return p

def pubmed_search(query, retmax, settings):
    params={'db':'pubmed','term':query,'retmode':'json','retmax':str(retmax),'sort':'relevance'}; params.update(ncbi_params(settings))
    r=requests.get('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi',params=params,timeout=25); r.raise_for_status()
    js=r.json()['esearchresult']; return int(js.get('count',0)), js.get('idlist',[])

def fetch_details(pmids, settings):
    if not pmids: return []
    params={'db':'pubmed','id':','.join(pmids),'retmode':'xml'}; params.update(ncbi_params(settings))
    r=requests.get('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi',params=params,timeout=40); r.raise_for_status()
    root=ET.fromstring(r.content); rows=[]
    for art in root.findall('.//PubmedArticle'):
        pmid=art.findtext('.//PMID') or ''
        title=''.join(art.find('.//ArticleTitle').itertext()) if art.find('.//ArticleTitle') is not None else ''
        abstract=' '.join([''.join(x.itertext()).strip() for x in art.findall('.//AbstractText')])
        journal=art.findtext('.//Journal/Title') or art.findtext('.//ISOAbbreviation') or ''
        year=art.findtext('.//PubDate/Year') or art.findtext('.//PubMedPubDate/Year') or ''
        authors=[]
        for a in art.findall('.//Author')[:8]:
            name=((a.findtext('LastName') or '')+' '+(a.findtext('Initials') or '')).strip()
            if name: authors.append(name)
        rows.append({'pmid':pmid,'title':title,'year':year,'journal':journal,'authors':'; '.join(authors),'abstract':abstract,'url':f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/'})
    return rows

def ai_settings():
    st=load_settings(); cfg=PROVIDERS.get(st.get('provider','OpenAI / GPT'), PROVIDERS['OpenAI / GPT']); return st,cfg

def call_ai(prompt, system='你是一个严谨的医学科研文献检索与选题分析助手。输出中文，结构清晰，不编造。', temperature=0.2, max_tokens=1800):
    st,cfg=ai_settings(); typ=cfg.get('type','openai')
    api_key=(st.get('api_key') or '').strip(); base=(st.get('base_url') or cfg.get('base_url')).rstrip('/'); model=(st.get('model') or cfg.get('models',[None])[0] or '').strip()
    if typ!='ollama' and not api_key: raise RuntimeError('未填写 AI API Key。AI 扩展/分析需要填写；PubMed 检索本身不需要。')
    if not model: raise RuntimeError('未填写模型名。')
    if typ=='openai':
        r=requests.post(base+'/chat/completions',headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'},json={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':prompt}],'temperature':temperature,'max_tokens':max_tokens},timeout=100)
        if r.status_code>=400: raise RuntimeError(f'AI 请求失败 {r.status_code}: {r.text[:500]}')
        return r.json()['choices'][0]['message']['content']
    if typ=='anthropic':
        r=requests.post(base+'/v1/messages',headers={'x-api-key':api_key,'anthropic-version':'2023-06-01','Content-Type':'application/json'},json={'model':model,'system':system,'messages':[{'role':'user','content':prompt}],'max_tokens':max_tokens,'temperature':temperature},timeout=100)
        if r.status_code>=400: raise RuntimeError(f'Claude 请求失败 {r.status_code}: {r.text[:500]}')
        return ''.join([x.get('text','') for x in r.json().get('content',[])])
    if typ=='ollama':
        r=requests.post(base+'/api/chat',json={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':prompt}],'stream':False,'options':{'temperature':temperature}},timeout=160)
        if r.status_code>=400: raise RuntimeError(f'Ollama 请求失败 {r.status_code}: {r.text[:500]}')
        return r.json().get('message',{}).get('content','')
    raise RuntimeError('未知 AI 服务商')

def extract_query_from_ai(text):
    m=re.search(r'```(?:text)?\s*(.*?)```', text, re.S|re.I)
    q=(m.group(1) if m else text).strip()
    q=re.sub(r'^(PubMed检索式|检索式|Query)[:：]\s*','',q,flags=re.I).strip()
    return q.split('\n\n')[0].strip()

def safe_filename(prefix, ext): return f'{prefix}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.{ext}'
def export_csv(rows):
    name=safe_filename('pubmed_results','csv'); path=EXPORT_DIR/name; fields=['pmid','title','year','journal','authors','url','abstract']
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    return name

def export_ris(rows):
    name=safe_filename('zotero_import','ris'); path=EXPORT_DIR/name
    with open(path,'w',encoding='utf-8') as f:
        for r in rows:
            f.write('TY  - JOUR\n'); f.write(f'TI  - {r.get("title","")}\n')
            if r.get('year'): f.write(f'PY  - {r["year"]}\n')
            if r.get('journal'): f.write(f'JO  - {r["journal"]}\n')
            if r.get('pmid'): f.write(f'ID  - {r["pmid"]}\nUR  - {r["url"]}\n')
            for a in (r.get('authors') or '').split('; '):
                if a: f.write(f'AU  - {a}\n')
            f.write('ER  - \n\n')
    return name

def export_md(rows, query):
    name=safe_filename('gpt_analysis_pack','md'); path=EXPORT_DIR/name
    with open(path,'w',encoding='utf-8') as f:
        f.write('# PubMed 文献分析包\n\n## 检索式\n\n```text\n'+query+'\n```\n\n')
        f.write('## 给 GPT 的任务\n\n请判断方向是否饱和、是否已有大量 signature 文章、是否已有 qRT-PCR/WB 验证、是否适合本科生用公开数据库 + qRT-PCR/WB 完成，并给出可行选题。\n\n')
        for i,r in enumerate(rows,1):
            f.write(f'## {i}. {r.get("title","")}\n- PMID: {r.get("pmid","")}\n- Year: {r.get("year","")}\n- Journal: {r.get("journal","")}\n- URL: {r.get("url","")}\n- Abstract: {r.get("abstract","")[:1800]}\n\n')
    return name

@app.route('/')
def index(): return render_template('index.html')
@app.route('/api/providers')
def providers(): return jsonify(PROVIDERS)
@app.route('/api/settings',methods=['GET','POST'])
def settings():
    if request.method=='POST':
        s=save_settings(request.json or {}); log('设置已保存'); return jsonify({'ok':True,'settings':s})
    return jsonify(load_settings())
@app.route('/api/preview',methods=['POST'])
def preview(): return jsonify({'query':build_query(request.json or {})})
@app.route('/api/test_ai',methods=['POST'])
def test_ai():
    try: return jsonify({'ok':True,'message':'AI 连接成功：'+call_ai('请只回复：连接成功',max_tokens=50)[:80]})
    except Exception as e: log('AI 测试失败：'+repr(e)); return jsonify({'ok':False,'error':str(e)}),500
@app.route('/api/ai_expand_query',methods=['POST'])
def ai_expand_query():
    data=request.json or {}; basic=build_query(data)
    prompt=(f"""
请把下面用户的医学研究需求，扩展成更适合 PubMed 的宽检索式。
要求：
1. 不要默认加入 qRT-PCR、Western blot、TCGA、GEO，除非用户明确填写在额外必须包含词。
2. 癌种、研究方向、结局词分别扩展同义词，用 OR 包裹。
3. 年份限制保留。
4. 作者/单位/期刊限定如有填写则保留。
5. 只输出 PubMed 检索式，不要解释。

癌种/疾病：{data.get('cancer','')}
研究方向：{data.get('direction','')}
结局/主题词：{data.get('topic','')}
起止年份：{data.get('start_year','')} - {data.get('end_year','')}
额外必须包含词：{data.get('required','')}
排除词：{data.get('exclude','')}
作者：{data.get('author','')}
单位：{data.get('affiliation','')}
期刊：{data.get('journal','')}
当前基础检索式：{basic}
""")
    try:
        log('开始 AI 扩展检索式'); ans=call_ai(prompt,max_tokens=1200); q=extract_query_from_ai(ans); log('AI 扩展检索式完成')
        return jsonify({'ok':True,'query':q,'raw':ans})
    except Exception as e: log('AI 扩展检索式失败：'+repr(e)); return jsonify({'ok':False,'error':str(e),'fallback':basic}),500
@app.route('/api/search',methods=['POST'])
def search():
    global last_results,last_query
    data=request.json or {}; settings=load_settings(); q=build_query(data); last_query=q; retmax=int(data.get('retmax') or 100)
    try:
        log('开始 PubMed 检索'); log('检索式：'+q); count,ids=pubmed_search(q,retmax,settings); log(f'PubMed 命中总数：{count}；本次抓取：{len(ids)}')
        rows=fetch_details(ids,settings); last_results=rows; log(f'文献信息解析完成：{len(rows)} 篇')
        return jsonify({'ok':True,'query':q,'count':count,'rows':rows,'logs':last_log})
    except Exception as e: log('错误：'+repr(e)); return jsonify({'ok':False,'error':str(e),'query':q,'logs':last_log}),500
@app.route('/api/ai_analyze',methods=['POST'])
def ai_analyze():
    if not last_results: return jsonify({'ok':False,'error':'请先完成 PubMed 检索，再进行 AI 分析。'}),400
    n=int((request.json or {}).get('n') or min(40,len(last_results))); sample=last_results[:max(1,min(n,80))]
    blocks=[]
    for i,r in enumerate(sample,1): blocks.append(f"[{i}] PMID: {r.get('pmid','')}\nTitle: {r.get('title','')}\nYear: {r.get('year','')}; Journal: {r.get('journal','')}\nAbstract: {(r.get('abstract') or '')[:1400]}")
    prompt=f"""
你正在帮助临床医学本科生做 PubMed 选题避坑。基于以下检索式和文献标题/摘要，输出科研方向分析。

检索式：
{last_query}

请输出：
1. 方向总体判断：是否饱和，为什么。
2. 文献类型粗分：signature/预后模型、机制研究、综述/meta、纯生信、实验验证、免疫相关等。
3. 已经高度重复的套路。
4. 是否有 qRT-PCR/WB 或实验验证痕迹：只根据摘要可见信息判断，不要编造。
5. 对本科生是否友好：公开数据库 + qRT-PCR/WB 能否完成。
6. 推荐 3-5 个更好的切入口。
7. 下一轮 PubMed 检索式建议，至少 3 条。

文献：
{chr(10).join(blocks)}
"""
    try:
        log(f'开始 AI 分析文献：{len(sample)} 篇'); ans=call_ai(prompt,max_tokens=3500); log('AI 分析完成')
        return jsonify({'ok':True,'analysis':ans,'used':len(sample)})
    except Exception as e: log('AI 分析失败：'+repr(e)); return jsonify({'ok':False,'error':str(e)}),500
@app.route('/api/export/<kind>',methods=['POST'])
def export(kind):
    if not last_results: return jsonify({'ok':False,'error':'当前没有可导出的检索结果'}),400
    if kind=='csv': name=export_csv(last_results)
    elif kind=='ris': name=export_ris(last_results)
    elif kind=='md': name=export_md(last_results,last_query)
    else: return jsonify({'ok':False,'error':'未知导出类型'}),400
    log(f'导出完成：{name}'); return jsonify({'ok':True,'file':name,'url':'/exports/'+quote(name)})
@app.route('/api/logs')
def logs(): return jsonify({'logs':last_log})
@app.route('/exports/<path:name>')
def download(name): return send_from_directory(str(EXPORT_DIR), name, as_attachment=True)

def open_browser(): webbrowser.open('http://127.0.0.1:8765')
if __name__=='__main__':
    threading.Timer(1.0, open_browser).start(); app.run(host='127.0.0.1',port=8765,debug=False)
