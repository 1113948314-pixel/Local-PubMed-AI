@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ResearchPilot Local Web Pro
if not exist ".venv\Scripts\python.exe" (
  echo First run: creating Python virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Python was not found. Please install Python 3.10+ and tick "Add Python to PATH".
    pause
    exit /b 1
  )
)
echo Installing/checking backend dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r backend\requirements.txt
if errorlevel 1 (
  echo Dependency installation failed.
  pause
  exit /b 1
)
echo Starting ResearchPilot Local Web Pro...
echo Browser will open automatically. If not, open: http://127.0.0.1:8765
".venv\Scripts\python.exe" backend\app.py
pause
