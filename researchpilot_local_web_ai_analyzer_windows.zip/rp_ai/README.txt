ResearchPilot Local Web AI Analyzer

用法：
1. 双击 run_windows.bat
2. 打开本地网页后，在 AI / NCBI 设置中填写 AI 服务商、API Key、模型名
3. 工作台可先“预览检索式”，也可点“AI 扩展检索式”生成更宽的 PubMed 检索式
4. 点击“开始检索 PubMed”
5. 检索完成后，点击“AI 分析当前结果”进行方向饱和度、文献类型、切入口分析

说明：
- PubMed 检索不需要 AI Key。
- AI 扩展检索式和 AI 分析需要 AI Key，或使用本地 Ollama。
- 所有 Key 只保存在本机 config/settings.json。
